import React, { useEffect,useState } from 'react'
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import axios from 'axios';


export const Home = () => {

    const [data,setdata]=useState([]);
    useEffect(()=>{
        axios.get('https://dummyapi.online/api/movies').then((res)=>{
             setdata(res.data);
        
        }).catch((err)=>{
        console.log(err);
        })
        },[])
    return (
        <Box sx={{ flexGrow: 1 }} style={{marginTop:'5%',marginLeft:'5%',marginRight:'5%',backgroundColor:'red',padding:'1%'}}>
          <Grid container spacing={2}>  
          {data.map((item)=>(
        
                <Grid item xs={4} >
            <Card sx={{ minWidth: 275 }} style={{backgroundColor:'lightyellow'}}>
      <CardContent>
        <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
              {item.id}
         </Typography>
        <Typography  component="div">
        {item.movie}
        </Typography>
        <Typography sx={{ mb: 1.5 }} color="text.secondary">
        {item.rating}
    </Typography>      
      </CardContent>
      <CardActions>
        <Button size="small">Learn More</Button>
      </CardActions>
    </Card>
            </Grid>

))}   
 
          </Grid>
        </Box>
      );
}
