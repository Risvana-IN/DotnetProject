import logo from './logo.svg';
import './App.css';
import { Home } from './Components/Home';
import Navbar from './Components/Navbar';
import { Routes } from "react-router-dom";
import {Route} from "react-router-dom";
import { Addmovie } from './Components/Addmovie';
import { Login } from './Components/Login';
import { Signup } from './Components/Signup';

function App() {
  return (
    <>
    <Navbar/>
    <Routes>
<Route path='/' element= {<Home/>}></Route>
<Route path='/addmovie' element= {<Addmovie/>}></Route>
<Route path='/login' element= {<Login/>}></Route>
<Route path='/signup' element= {<Signup/>}></Route>


</Routes>
   </>
  );
}

export default App;
